package com.example.bfs.testlviewinception;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[][] topicLists = {{"one,one","one,two","one,three","one,four","one,five"}
                ,{"two,one","two,two","two,three","two,four"}
                ,{"three,one","three,two","three,three","three,four","three,five","three,six"}
                ,{"four,one","four,two","four,three"}};

        ListView listView = (ListView) findViewById(R.id.recyclerView);
        CardAdapter cardsAdapter = new CardAdapter(this, topicLists);
        listView.setAdapter(cardsAdapter);
    }
}
